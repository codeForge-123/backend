-- Database schema for Task_Manager
CREATE TABLE users(id INT PRIMARY KEY);