function App() {
  return <h1>smart attendance system - MERN Frontend</h1>;
}

export default App;